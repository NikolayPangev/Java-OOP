package WorkingWithAbstraction_Exercise.CardSuit;

public enum Suits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
