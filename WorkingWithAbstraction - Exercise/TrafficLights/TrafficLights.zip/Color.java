package WorkingWithAbstraction_Exercise.TrafficLights;

public enum Color {
    RED,
    YELLOW,
    GREEN
}
